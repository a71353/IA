import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

class TripleTest {

	@Test
	void testChildren() {
		Triple teste = new Triple(1,0);
		List<Ilayout> children = teste.children();
		assertTrue(children.get(0).equals(new Triple(2,1)));
		assertTrue(children.get(1).equals(new Triple(0,2)));
		assertTrue(children.get(2).equals(new Triple(2,3)));
		teste = new Triple(-2,0);
		children = teste.children();
		assertTrue(children.get(0).equals(new Triple(-1,1)));
		assertTrue(children.get(1).equals(new Triple(-3,2)));
		assertTrue(children.get(2).equals(new Triple(-4,3)));
	}
	
	@Test
	void testHeuristic() {
		Triple teste1 = new Triple(4,0);
		Triple teste2 = new Triple(6,0);
		Triple teste3 = new Triple(11,0);
		Triple goal = new Triple(12,0);
		
		assertTrue(teste1.getHeuristic(goal) == 2);
		assertTrue(teste2.getHeuristic(goal) == 0);
		assertTrue(teste3.getHeuristic(goal) == 1);
		assertTrue(goal.getHeuristic(goal) == 0);
		assertFalse(teste1.getHeuristic(goal) == 3);
	}

}
