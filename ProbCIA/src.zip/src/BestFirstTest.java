import static org.junit.jupiter.api.Assertions.*;

import java.util.Iterator;
import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.Test;

class BestFirstTest {
	
	@Test
	void testConstructorState() {
		Triple a = new Triple(2,0);
		Triple b = new Triple(3,1);
		Triple c = new Triple(6,3);
		BestFirst.State teste1 = new BestFirst.State(a, null);
		BestFirst.State teste2 = new BestFirst.State(b, teste1);
		BestFirst.State teste3 = new BestFirst.State(c, teste2);
		assertTrue(teste1.getG() == 0);
		assertTrue(teste2.getG() == 1);
		assertTrue(teste3.getG() == 4);
	}
	
	 @Test
	    public void testSolve() {
		 
	        Triple layout = new Triple(4,0); 
	        Triple goal = new Triple(12,0); 
	        BestFirst s = new BestFirst();

	        Iterator<BestFirst.State> result = s.solve(layout, goal);
	        assertNotNull(result);
	        
	        String actual = "";
	        String expected = "4 5 6 12 5";

	        while(result.hasNext()) {
				BestFirst.State i = result.next();
				actual += i + " ";
				if (!result.hasNext()) {
					actual += (int)i.getG();
				}
			}
	        
	        assertTrue(actual.equals(expected));
	        
	        layout = new Triple(-7,0); 
	        goal = new Triple(-21,0); 
	        result = s.solve(layout, goal);
	        assertNotNull(result);
	        
	        actual = "";
	        expected = "-7 -6 -12 -11 -22 -21 9";

	        while(result.hasNext()) {
				BestFirst.State i = result.next();
				actual += i + " ";
				if (!result.hasNext()) {
					actual += (int)i.getG();
				}
			}
	        
	        assertTrue(actual.equals(expected));
	        
	        layout = new Triple(10,0); 
	        goal = new Triple(30,0); 
	        result = s.solve(layout, goal);
	        assertNotNull(result);
	        
	        actual = "";
	        expected = "10 11 12 13 14 15 30 8";

	        while(result.hasNext()) {
				BestFirst.State i = result.next();
				actual += i + " ";
				if (!result.hasNext()) {
					actual += (int)i.getG();
				}
			}
	        
	        assertTrue(actual.equals(expected));
	        
	        layout = new Triple(0,0); 
	        goal = new Triple(0,0); 
	        result = s.solve(layout, goal);
	        assertNotNull(result);
	        
	        actual = "";
	        expected = "0 0";

	        while(result.hasNext()) {
				BestFirst.State i = result.next();
				actual += i + " ";
				if (!result.hasNext()) {
					actual += (int)i.getG();
				}
			}
	        
	        assertTrue(actual.equals(expected));
	    }
	 
	 @Test
	    public void testSolveAStar() {
		 
	        Triple layout = new Triple(4,0); 
	        Triple goal = new Triple(12,0); 
	        BestFirst s = new BestFirst();

	        Iterator<BestFirst.State> result = s.solveAStar(layout, goal);
	        assertNotNull(result);
	        
	        String actual = "";
	        String expected = "4 5 6 12 5";

	        while(result.hasNext()) {
				BestFirst.State i = result.next();
				actual += i + " ";
				if (!result.hasNext()) {
					actual += (int)i.getG();
				}
			}
	        
	        assertTrue(actual.equals(expected));
	        
	        layout = new Triple(-7,0); 
	        goal = new Triple(-21,0); 
	        result = s.solveAStar(layout, goal);
	        assertNotNull(result);
	        
	        actual = "";
	        expected = "-7 -6 -12 -11 -22 -21 9";

	        while(result.hasNext()) {
				BestFirst.State i = result.next();
				actual += i + " ";
				if (!result.hasNext()) {
					actual += (int)i.getG();
				}
			}
	        
	        assertTrue(actual.equals(expected));
	        
	        layout = new Triple(10,0); 
	        goal = new Triple(30,0); 
	        result = s.solveAStar(layout, goal);
	        assertNotNull(result);
	        
	        actual = "";
	        expected = "10 11 12 13 14 15 30 8";

	        while(result.hasNext()) {
				BestFirst.State i = result.next();
				actual += i + " ";
				if (!result.hasNext()) {
					actual += (int)i.getG();
				}
			}
	        
	        assertTrue(actual.equals(expected));
	        
	        layout = new Triple(0,0); 
	        goal = new Triple(0,0); 
	        result = s.solveAStar(layout, goal);
	        assertNotNull(result);
	        
	        actual = "";
	        expected = "0 0";

	        while(result.hasNext()) {
				BestFirst.State i = result.next();
				actual += i + " ";
				if (!result.hasNext()) {
					actual += (int)i.getG();
				}
			}
	        
	        assertTrue(actual.equals(expected));
	        
	        layout = new Triple(12345,0); 
	        goal = new Triple(37035,0);
	        long startTime = System.nanoTime();
	        result = s.solveAStar(layout, goal);
	        long endTime = System.nanoTime();
	        long elapsedTime = endTime - startTime;
	        long elapsedTimeInMillis = TimeUnit.NANOSECONDS.toMillis(elapsedTime);
	        //CPUS mais fracos podem nao conseguir passar a este teste
	        assertTrue(elapsedTimeInMillis < 1000);
	        
	        layout = new Triple(-12345,0); 
	        goal = new Triple(-37035,0);
	        startTime = System.nanoTime();
	        result = s.solveAStar(layout, goal);
	        endTime = System.nanoTime();
	        elapsedTime = endTime - startTime;
	        elapsedTimeInMillis = TimeUnit.NANOSECONDS.toMillis(elapsedTime);
	        assertTrue(elapsedTimeInMillis < 1000);
	    }
	 
	 @Test
	    public void testSolveIDAStar() {
		 
	        Triple layout = new Triple(4,0); 
	        Triple goal = new Triple(12,0); 
	        BestFirst s = new BestFirst();

	        Iterator<BestFirst.State> result = s.solveIDAStar(layout, goal);
	        assertNotNull(result);
	        
	        String actual = "";
	        String expected = "4 5 6 12 5";

	        while(result.hasNext()) {
				BestFirst.State i = result.next();
				actual += i + " ";
				if (!result.hasNext()) {
					actual += (int)i.getG();
				}
			}
	        
	        assertTrue(actual.equals(expected));
	        
	        layout = new Triple(-7,0); 
	        goal = new Triple(-21,0); 
	        result = s.solveIDAStar(layout, goal);
	        assertNotNull(result);
	        
	        actual = "";
	        expected = "-7 -6 -12 -11 -22 -21 9";

	        while(result.hasNext()) {
				BestFirst.State i = result.next();
				actual += i + " ";
				if (!result.hasNext()) {
					actual += (int)i.getG();
				}
			}
	        
	        assertTrue(actual.equals(expected));
	        
	        layout = new Triple(10,0); 
	        goal = new Triple(30,0); 
	        result = s.solveIDAStar(layout, goal);
	        assertNotNull(result);
	        
	        actual = "";
	        expected = "10 11 12 13 14 15 30 8";

	        while(result.hasNext()) {
				BestFirst.State i = result.next();
				actual += i + " ";
				if (!result.hasNext()) {
					actual += (int)i.getG();
				}
			}
	        
	        assertTrue(actual.equals(expected));
	        
	        layout = new Triple(0,0); 
	        goal = new Triple(0,0); 
	        result = s.solveIDAStar(layout, goal);
	        assertNotNull(result);
	        
	        actual = "";
	        expected = "0 0";

	        while(result.hasNext()) {
				BestFirst.State i = result.next();
				actual += i + " ";
				if (!result.hasNext()) {
					actual += (int)i.getG();
				}
			}
	        
	        assertTrue(actual.equals(expected));
	        
	        layout = new Triple(12345,0); 
	        goal = new Triple(37035,0);
	        long startTime = System.nanoTime();
	        result = s.solveIDAStar(layout, goal);
	        long endTime = System.nanoTime();
	        long elapsedTime = endTime - startTime;
	        long elapsedTimeInMillis = TimeUnit.NANOSECONDS.toMillis(elapsedTime);
	        assertTrue(elapsedTimeInMillis < 1000);
	        
	        layout = new Triple(-12345,0); 
	        goal = new Triple(-37035,0);
	        startTime = System.nanoTime();
	        result = s.solveIDAStar(layout, goal);
	        endTime = System.nanoTime();
	        elapsedTime = endTime - startTime;
	        elapsedTimeInMillis = TimeUnit.NANOSECONDS.toMillis(elapsedTime);
	        assertTrue(elapsedTimeInMillis < 1000);
	    }

}
