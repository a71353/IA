import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Random;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Test class for CarloAgent.
 */
class CarloAgentTest {

    @Test
    void select() {
        CarloAgent teste = new CarloAgent();
        Board board = new Board();
        CarloAgent.State state = teste.new State(null, board);
        List<Ilayout> testList = board.children();
        for(Ilayout i : testList){
            state.childArray.add(teste.new State(state, i));
        }
        int totalVisits = 0;
        for (int i = 0; i < testList.size(); i++) {
            state.childArray.get(i).visitCount = i;
            totalVisits += i;
        }
        state.visitCount = totalVisits;
        teste.root = state;
        assertEquals(state.childArray.get(0), teste.select(state));
    }

    @Test
    void expand() {
        CarloAgent teste = new CarloAgent();
        Board board = new Board();
        CarloAgent.State state = teste.new State(null, board);
        List<Ilayout> testList = board.children();
        teste.expand(state);
        assertEquals(testList.size(), state.childArray.size());
        for (int i = 0; i < testList.size(); i++) {
            assertEquals(testList.get(i), state.childArray.get(i).layout);
        }
    }

    @Test
    void simulate() {
        CarloAgent teste = new CarloAgent();
        Board board = new Board();
        board.move(0);
        board.move(1);
        board.move(2);
        board.move(3);
        board.move(4);
        board.move(5);
        board.move(6);
        board.move(7);
        board.move(8);
        board.move(9);
        board.move(10);
        board.move(11);
        board.move(13);
        board.move(12);
        board.move(15);
        CarloAgent.State state = teste.new State(null, board);
        teste.root = state;
        assertEquals(0, teste.simulate(state));
        board.reset();
        board.move(0);
        board.move(1);
        board.move(2);
        board.move(3);
        board.move(5);
        board.move(4);
        board.move(8);
        board.move(6);
        board.move(9);
        board.move(7);
        board.move(10);
        board.move(12);
        board.move(14);
        board.move(13);
        state = teste.new State(null, board);
        teste.root = state;
        assertEquals(1, teste.simulate(state));
    }

    @Test
    void backpropagate() {
        CarloAgent teste = new CarloAgent();
        Board board = new Board();
        CarloAgent.State state = teste.new State(null, board);
        teste.expand(state);
        int totalVisits = 0;
        for (int i = 0; i < state.childArray.size(); i++) {
            state.childArray.get(i).visitCount = i;
            totalVisits += i;
        }
        state.visitCount = totalVisits;
        teste.backpropagate(state.childArray.get(5), 1);
        assertEquals(totalVisits+1, state.visitCount);
        assertEquals(1, state.childArray.get(5).winScore);
        assertEquals(1, state.winScore);
        assertEquals(6, state.childArray.get(5).visitCount);
    }

    @Test
    void findBestChildUsingUCT() {
        CarloAgent teste = new CarloAgent();
        Board board = new Board();
        CarloAgent.State state = teste.new State(null, board);
        List<Ilayout> testList = board.children();
        for(Ilayout i : testList){
            state.childArray.add(teste.new State(state, i));
        }
        int totalVisits = 0;
        for (int i = 0; i < testList.size(); i++) {
            state.childArray.get(i).visitCount = i;
            totalVisits += i;
        }
        state.visitCount = totalVisits;
        teste.root = state;
        assertEquals(state.childArray.get(0), teste.findBestChildUsingUCT(state));
    }
}