import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Test class for Board.

 */
class BoardTest {

    @org.junit.jupiter.api.Test
    void getWinner() {
        Board test = new Board();
        test.move(0);
        test.move(1);
        test.move(4);
        test.move(2);
        test.move(8);
        test.move(3);
        test.move(12);
        assertEquals(test.getWinner(), Ilayout.ID.X);
        test.reset();
        test.move(0);
        test.move(4);
        test.move(1);
        test.move(5);
        test.move(2);
        test.move(6);
        test.move(3);
        assertEquals(test.getWinner(), Ilayout.ID.X);
        test.reset();
        test.move(0);
        test.move(3);
        test.move(1);
        test.move(6);
        test.move(2);
        test.move(9);
        test.move(4);
        test.move(12);
        assertEquals(test.getWinner(), Ilayout.ID.O);
        test.reset();
        test.move(0);
        test.move(4);
        test.move(5);
        test.move(6);
        test.move(10);
        test.move(7);
        test.move(15);
        assertEquals(test.getWinner(), Ilayout.ID.X);
    }

    @org.junit.jupiter.api.Test
    void children() {
        Board test = new Board();
        test.move(0);
        List<Ilayout> testList =  test.children();
        assertEquals(testList.size(), 15);
        for (int i = 0; i < 15; i++) {
            Board test2 = (Board) test.clone();
            test2.move(i+1);
            assertEquals(testList.get(i), test2);
        }
    }

    @org.junit.jupiter.api.Test
    void getLastMove() {
        Board test = new Board();
        test.move(0);
        test.move(1);
        test.move(4);
        Board test2 = (Board) test.clone();
        test2.move(10);
        assertEquals(test.getLastMove(test2), 10);
        test2 = (Board) test.clone();
        test2.move(11);
        assertEquals(test.getLastMove(test2), 11);
        test2 = (Board) test.clone();
        test2.move(3);
        assertEquals(test.getLastMove(test2), 3);
    }
}