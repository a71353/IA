import static org.junit.jupiter.api.Assertions.*;

import java.io.PrintWriter;
import java.io.StringWriter;

import org.junit.jupiter.api.Test;

import java.util.*;


public class TripleUnitTests {

    @Test
    public void testEquals() {
        Triple triple1 = new Triple(5);
        Triple triple2 = new Triple(5);
        Triple triple3 = new Triple(10);

        assertTrue(triple1.equals(triple2));
        assertFalse(triple1.equals(triple3));
    }

    @Test
    public void testChildren() {
        Triple triple = new Triple(2);
        List<Ilayout> children = triple.children();

        assertEquals(3, children.size());

        Triple child1 = (Triple) children.get(0);
        assertEquals(3, child1.number);
        assertEquals(1, child1.cost);

        Triple child2 = (Triple) children.get(1);
        assertEquals(1, child2.number);
        assertEquals(2, child2.cost);

        Triple child3 = (Triple) children.get(2);
        assertEquals(4, child3.number);
        assertEquals(3, child3.cost);
    }

    @Test
    public void testIsGoal() {
        Triple triple1 = new Triple(5);
        Triple triple2 = new Triple(10);

        assertTrue(triple1.isGoal(triple1));
        assertFalse(triple1.isGoal(triple2));
    }

    @Test
    public void testGetG() {
        Triple triple = new Triple(3);
        assertEquals(0, triple.getG());

        Triple triple1 = new Triple(3);
        triple1.cost = 10;
        assertEquals(10, triple1.getG());
    }

    @Test
    public void testToString() {
        Triple triple = new Triple(7);
        assertEquals("7", triple.toString());
    }

}
