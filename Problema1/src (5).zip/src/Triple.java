import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.*;

public class Triple implements Ilayout, Cloneable {

    public int number;
    public int cost;

    public Triple(int number) throws IllegalStateException {
        this.number = number;
        this.cost = 0;
    }

    public boolean equals(Object o) {
        Triple obj = (Triple) o;
        return this.number == obj.number;
    }


    public int hashCode()
    {
        return toString().hashCode();
    }

    @Override
    public List<Ilayout> children() {
        List<Ilayout> children = new ArrayList<>();

        Triple add = new Triple(number + 1);
        add.cost = 1;
        children.add(add);

        Triple sub = new Triple(number - 1);
        sub.cost = 2;
        children.add(sub);

        Triple mult = new Triple(number * 2);
        mult.cost = 3;
        children.add(mult);

        return children;
    }

    @Override
    public boolean isGoal(Ilayout l) {
        return this.equals(l);
    }

    @Override
    public int getG() {
        return cost;
    }

    public String toString() {
        return String.valueOf(number);
    }


}
